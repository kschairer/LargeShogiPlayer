#include "AngryBoar.h"

void AngryBoar::SetPieceMovement()
{
	stepMoves = " F R B L ";
	lionMoves = "";
	rangeMoves = "  ";
	jumpMoves = "  ";
	name = "Angry Boar";
	abrName2 = "A";
	abrName = "B";
	isPromotable = true;


	TextureSetup();
}